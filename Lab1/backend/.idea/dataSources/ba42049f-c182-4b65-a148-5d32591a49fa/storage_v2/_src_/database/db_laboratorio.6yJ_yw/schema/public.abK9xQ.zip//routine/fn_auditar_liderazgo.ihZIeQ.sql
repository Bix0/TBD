create function fn_auditar_liderazgo() returns trigger
    language plpgsql
as
$$ BEGIN IF OLD.id_lider IS DISTINCT FROM NEW.id_lider THEN INSERT INTO Auditoria_Liderazgo (id_clan, id_antiguo_lider, id_nuevo_lider) VALUES (NEW.id_clan, OLD.id_lider, NEW.id_lider); END IF; RETURN NEW; END; $$;

alter function fn_auditar_liderazgo() owner to admin_raid;

