create materialized view mv_ranking_clan as
SELECT p.id_personaje,
       p.nombre,
       p.clase,
       p.puntos_merito         AS dkp_actual,
       count(i.id_inscripcion) AS total_raids_asistidas
FROM personaje p
         JOIN inscripcion_raid i ON p.id_personaje = i.id_personaje
WHERE i.asistio = true
GROUP BY p.id_personaje, p.nombre, p.clase, p.puntos_merito
ORDER BY (count(i.id_inscripcion)) DESC, p.puntos_merito DESC;

alter materialized view mv_ranking_clan owner to admin_raid;

