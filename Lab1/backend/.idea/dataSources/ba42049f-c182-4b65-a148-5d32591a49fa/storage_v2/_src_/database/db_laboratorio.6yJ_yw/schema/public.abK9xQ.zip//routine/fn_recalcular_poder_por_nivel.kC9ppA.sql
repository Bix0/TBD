create function fn_recalcular_poder_por_nivel() returns trigger
    language plpgsql
as
$$ DECLARE v_poder_armas INT; BEGIN SELECT COALESCE(SUM(i.item_lvl), 0) INTO v_poder_armas FROM Inventario inv JOIN Item i ON inv.id_item = i.id_item WHERE inv.id_personaje = NEW.id_personaje AND inv.equipado = TRUE; UPDATE Personaje SET item_level = NEW.nivel + v_poder_armas WHERE id_personaje = NEW.id_personaje; RETURN NEW; END; $$;

alter function fn_recalcular_poder_por_nivel() owner to admin_raid;

