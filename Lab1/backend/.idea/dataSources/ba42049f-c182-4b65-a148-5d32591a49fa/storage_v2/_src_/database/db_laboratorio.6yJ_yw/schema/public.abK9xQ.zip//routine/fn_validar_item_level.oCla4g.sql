create function fn_validar_item_level() returns trigger
    language plpgsql
as
$$ DECLARE v_ilvl_personaje INT; v_ilvl_raid INT; BEGIN SELECT item_level INTO v_ilvl_personaje FROM Personaje WHERE id_personaje = NEW.id_personaje; SELECT item_level_requerido INTO v_ilvl_raid FROM Raid WHERE id_raid = NEW.id_raid; IF v_ilvl_personaje < v_ilvl_raid THEN RAISE EXCEPTION 'Poder Insuficiente'; END IF; RETURN NEW; END; $$;

alter function fn_validar_item_level() owner to admin_raid;

