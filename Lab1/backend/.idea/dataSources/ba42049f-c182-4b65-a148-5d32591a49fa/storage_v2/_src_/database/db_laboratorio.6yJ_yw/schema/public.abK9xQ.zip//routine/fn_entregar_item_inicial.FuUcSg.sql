create function fn_entregar_item_inicial() returns trigger
    language plpgsql
as
$$ BEGIN INSERT INTO Inventario (id_item, id_personaje, cantidad, equipado) VALUES (1, NEW.id_personaje, 1, TRUE); RETURN NEW; END; $$;

alter function fn_entregar_item_inicial() owner to admin_raid;

