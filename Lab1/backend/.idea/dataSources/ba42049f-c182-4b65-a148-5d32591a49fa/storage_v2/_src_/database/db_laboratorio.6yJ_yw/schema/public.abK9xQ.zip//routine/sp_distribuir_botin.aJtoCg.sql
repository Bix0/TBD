create procedure sp_distribuir_botin(IN p_id_personaje bigint, IN p_id_item bigint, IN p_id_raid bigint, IN p_costo_dkp integer)
    language plpgsql
as
$$ BEGIN UPDATE Personaje SET puntos_merito = puntos_merito - p_costo_dkp WHERE id_personaje = p_id_personaje; INSERT INTO Historial_Loot (id_raid, id_personaje, id_item, estado_loot) VALUES (p_id_raid, p_id_personaje, p_id_item, 'Botín Ganado'); INSERT INTO Inventario (id_item, id_personaje, cantidad, equipado) VALUES (p_id_item, p_id_personaje, 1, FALSE); UPDATE Raid SET estado = 'Completada' WHERE id_raid = p_id_raid; UPDATE Inscripcion_Raid SET asistio = TRUE, estado = 'Completada' WHERE id_raid = p_id_raid; END; $$;

alter procedure sp_distribuir_botin(bigint, bigint, bigint, integer) owner to admin_raid;

