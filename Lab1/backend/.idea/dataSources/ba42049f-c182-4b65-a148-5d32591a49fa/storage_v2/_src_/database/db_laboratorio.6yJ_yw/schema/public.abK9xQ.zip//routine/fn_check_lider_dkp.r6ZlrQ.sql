create function fn_check_lider_dkp() returns trigger
    language plpgsql
as
$$ DECLARE v_lider_actual_personaje INT; v_lider_actual_dkp INT; v_clan_real INT; BEGIN v_clan_real := COALESCE(NEW.id_clan, (CASE WHEN NEW.faccion = 'Alianza' THEN 1 ELSE 2 END)); SELECT id_lider INTO v_lider_actual_personaje FROM Clan WHERE id_clan = v_clan_real; SELECT COALESCE(MAX(puntos_merito), 0) INTO v_lider_actual_dkp FROM Personaje WHERE id_personaje = v_lider_actual_personaje; IF NEW.puntos_merito > v_lider_actual_dkp AND NEW.id_personaje != v_lider_actual_personaje THEN UPDATE Clan SET id_lider = NEW.id_personaje WHERE id_clan = v_clan_real; END IF; RETURN NEW; END; $$;

alter function fn_check_lider_dkp() owner to admin_raid;

