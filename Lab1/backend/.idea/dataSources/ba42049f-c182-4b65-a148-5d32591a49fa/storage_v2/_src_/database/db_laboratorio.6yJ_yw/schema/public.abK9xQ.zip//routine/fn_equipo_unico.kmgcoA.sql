create function fn_equipo_unico() returns trigger
    language plpgsql
as
$$ BEGIN IF NEW.equipado = TRUE THEN UPDATE Inventario SET equipado = FALSE WHERE id_personaje = NEW.id_personaje AND id_inventario <> NEW.id_inventario AND equipado = TRUE; END IF; RETURN NEW; END; $$;

alter function fn_equipo_unico() owner to admin_raid;

