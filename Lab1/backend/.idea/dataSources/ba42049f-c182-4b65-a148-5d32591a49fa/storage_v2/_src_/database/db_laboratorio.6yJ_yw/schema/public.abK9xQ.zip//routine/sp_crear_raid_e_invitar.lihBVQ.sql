create procedure sp_crear_raid_e_invitar(IN p_nombre character varying, IN p_fecha timestamp without time zone, IN p_item_level integer, IN p_tanques integer, IN p_healers integer, IN p_dps integer)
    language plpgsql
as
$$ DECLARE v_id_raid_nueva INT; BEGIN INSERT INTO Raid (nombre, fecha, estado, item_level_requerido, cupos_tanque, cupos_healer, cupos_dps) VALUES (p_nombre, p_fecha, 'Programada', p_item_level, p_tanques, p_healers, p_dps) RETURNING id_raid INTO v_id_raid_nueva; INSERT INTO Inscripcion_Raid (id_raid, id_personaje, estado, asistio) SELECT v_id_raid_nueva, id_personaje, 'Pendiente', FALSE FROM Personaje WHERE rol_clan = 'Raider'; END; $$;

alter procedure sp_crear_raid_e_invitar(varchar, timestamp, integer, integer, integer, integer) owner to admin_raid;

