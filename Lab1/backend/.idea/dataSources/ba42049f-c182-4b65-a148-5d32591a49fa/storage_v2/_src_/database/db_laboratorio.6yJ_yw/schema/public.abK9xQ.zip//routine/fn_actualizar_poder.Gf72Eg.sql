create function fn_actualizar_poder() returns trigger
    language plpgsql
as
$$ DECLARE v_personaje_id INT; v_poder_armas INT; BEGIN v_personaje_id := COALESCE(NEW.id_personaje, OLD.id_personaje); SELECT COALESCE(SUM(i.item_lvl), 0) INTO v_poder_armas FROM Inventario inv JOIN Item i ON inv.id_item = i.id_item WHERE inv.id_personaje = v_personaje_id AND inv.equipado = TRUE; UPDATE Personaje SET item_level = nivel + v_poder_armas WHERE id_personaje = v_personaje_id; RETURN NEW; END; $$;

alter function fn_actualizar_poder() owner to admin_raid;

